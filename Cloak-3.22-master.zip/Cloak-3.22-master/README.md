# Cloak-3.22
A black transparent theme for Gtk-3.22
